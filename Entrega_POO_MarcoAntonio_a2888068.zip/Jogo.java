// Nome: Marco Antonio Teodoro da Silva
// RA: a2888068

public abstract class Jogo implements Calculavel {

    private int codigo;
    private String titulo;
    private String genero;
    private String plataforma;
    private double valorDiaria;

    // Default
    public Jogo() {
        this.codigo = 0;
        this.titulo = "";
        this.genero = "";
        this.plataforma = "";
        this.valorDiaria = 0.0;
    }

    public int getCodigo() {
        return this.codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getTitulo() {
        return this.titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getGenero() {
        return this.genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getPlataforma() {
        return this.plataforma;
    }

    public void setPlataforma(String plataforma) {
        this.plataforma = plataforma;
    }

    public double getValorDiaria() {
        return this.valorDiaria;
    }

    public void setValorDiaria(double valorDiaria) {
        this.valorDiaria = valorDiaria;
    }

    // Sobrescrita
    @Override
    public double calcularValorBase(int dias) {
        if (dias <= 0) {
            return 0.0;
        }
        return this.valorDiaria * dias;
    }

    //Sobrecarga
    public double calcularValorBase(int dias, double descontoReais) {
        double base = this.calcularValorBase(dias);
        if (descontoReais <= 0.0 || descontoReais >= base) {
            return base;
        }
        return base - descontoReais;
    }

    public abstract double calcularMultaPorDia();

    public abstract String obterTipoMidia();
}
